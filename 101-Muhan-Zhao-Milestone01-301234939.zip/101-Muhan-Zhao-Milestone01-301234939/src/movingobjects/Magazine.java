package movingobjects;

import static java.lang.Math.abs;
import static java.lang.Math.sqrt;

import java.awt.Graphics2D;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Magazine extends MovingObjects
{

	private final static int MAX_AMMO = 30;
	private int numLoaded;
	
	public Magazine(double posx, double posy) {
		super(posx, posy);
		// TODO Auto-generated constructor stub
		try {
			avatar = ImageIO.read(getClass().getResourceAsStream("/graphics/ar15magazine.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		width = 360*.7;
		height = 336.8*.7;
		
		numLoaded = 0;
	}

	@Override
	public void draw(Graphics2D g2) {
		// TODO Auto-generated method stub
		g2.drawImage(avatar, (int) (posx-width/2), (int) (posy-height/2), (int) width, (int) height, null);
	}
	
//	SPECIAL DISTANCE FOR MAGAZINE CALCULATION. AIMING FOR THE TOP OF THE ENTRANCE
	public double distMag(MovingObjects target)
	{
		return sqrt((abs(posx-target.posx)*abs(posx-target.posx))+
				(abs((posy-(width/2*.9))-target.posy)*abs((posy-(width/2*.9))-target.posy)));
	}
	
	public boolean reload()
	{
		if (numLoaded < MAX_AMMO)
		{
			numLoaded++;
			return true;
		}
		return false;
	}
}
