package movingobjects;

import java.awt.Graphics2D;
import java.io.IOException;

import javax.imageio.ImageIO;

/* GUNM4PIN class provides the animation and logistics of moving the Rifle's manual reload object
 * CREATED: 11/17/2016
 * AUTHOR: HENRY ZHAO*/
public class GunM4Pin extends MovingObjects
{	
	/* WHAT IT DOES: Constructor for GunM4Pin class 
	 * PARAMETERS: 
	 * 	posx - position x
	 * 	posy - position y
	 * RETURN: NONE*/
	public GunM4Pin(double posx, double posy) {
		super(posx, posy);
//		994.0
//		433.0
		// TODO Auto-generated constructor stub
		width = 594*0.4;
		height = 57*0.4;
		try {
			avatar = ImageIO.read(getClass().getResourceAsStream("/assets/reloadTrigger.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/* WHAT IT DOES: Draws the GunM4Pin object at the appropriate location on the GunM4 object 
	 * PARAMETERS: 
	 * 	g2 - Graphics2D brush
	 * RETURN: NONE*/
	@Override
	public void draw(Graphics2D g2) {
		// TODO Auto-generated method stub
		g2.drawImage(avatar, (int) (posx-width/2), (int) (posy-height/2), (int) width, (int) height, null);
	}
}
