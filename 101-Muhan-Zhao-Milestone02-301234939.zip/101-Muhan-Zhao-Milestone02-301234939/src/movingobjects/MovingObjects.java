package movingobjects;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import static java.lang.Math.*;

public abstract class MovingObjects {
	protected double posx;
	protected double posy;
	protected double velx;
	protected double vely;
	protected double width;
	protected double height;
	protected BufferedImage avatar;
	protected double angle;
	
	public MovingObjects(double posx, double posy)
	{
		this.posx = posx;
		this.posy = posy;
	}

	public boolean handleCollision(MovingObjects target)
	{
		if (Math.abs(posx - target.posx) <= width/2 + target.width/2 && Math.abs(posy - target.posy) <= height/2 + target.height/2)
		{
			return true;
		}
		return false;
	}
	
	public abstract void draw(Graphics2D g2);
	
	public double dist(MovingObjects target)
	{
		return sqrt((abs(posx-target.posx)*abs(posx-target.posx))+
				(abs(posy-target.posy)*abs(posy-target.posy)));
	}
	
	public void setPos(double x, double y)
	{
		posx = x;
		posy = y;
	}
	
	public double getW()
	{
		return width;
	}
	public double getH()
	{
		return height;
	}
	
	public double getX()
	{
		return posx;
	}
	
	public double getY()
	{
		return posy;
	}
	public void setAngle(double theta)
	{
		angle = Math.toRadians(theta);
	}
}
